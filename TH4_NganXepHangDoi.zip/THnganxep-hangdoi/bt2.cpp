#include <iostream>
#include <queue>
#include <cstring>
using namespace std;

struct Dancer {
    char Name[100];
    char Sex[10];
};

void GetName(Dancer &d, const char *s) {
    strcpy(d.Name, s);
}

char* ToString(Dancer &d) {
    return d.Name;
}

void NewDancers(queue<Dancer> &male, queue<Dancer> &female) {
    if (!male.empty() && !female.empty()) {
        Dancer m = male.front(); male.pop();
        Dancer w = female.front(); female.pop();
        printf("Cap dien vien: %s va %s\n", m.Name, w.Name);
    } else if (!male.empty()) {
        printf("Dang cho dien vien nu.\n");
    } else if (!female.empty()) {
        printf("Dang cho dien vien nam.\n");
    }
}

void HeadOfLine(queue<Dancer> &male, queue<Dancer> &female) {
    if (!male.empty() && !female.empty()) {
        printf("Cap dien vien ke tiep: %s \t %s\n", male.front().Name, female.front().Name);
    } else if (!male.empty()) {
        printf("Dien vien nam ke tiep: %s\n", male.front().Name);
    } else if (!female.empty()) {
        printf("Dien vien nu ke tiep: %s\n", female.front().Name);
    }
}

void StartDancing(queue<Dancer> &male, queue<Dancer> &female) {
    printf("Cac cap dien vien:\n");
    for (int i = 0; i < 4 && !male.empty() && !female.empty(); i++) {
        Dancer m = male.front(); male.pop();
        Dancer w = female.front(); female.pop();
        printf("%s\t%s\n", m.Name, w.Name);
    }
}

void ShowQueue(queue<Dancer> q) {
    while (!q.empty()) {
        printf("%s\n", q.front().Name);
        q.pop();
    }
}

void FormLines(queue<Dancer> &male, queue<Dancer> &female) {
    Dancer d;
    const char *dancers[] = {"F Trang", "M Truc", "M Thien", "M Bao", "F Thu", "M Tien", "F Thuy", "M Nghia", "F Thao", "M Phuoc", "M Hung", "F Vy"};
    int n = 12;
    for (int i = 0; i < n; i++) {
        strncpy(d.Sex, dancers[i], 1);
        d.Sex[1] = '\0';
        strcpy(d.Name, dancers[i] + 2);
        if (strcmp(d.Sex, "M") == 0) {
            male.push(d);
        } else {
            female.push(d);
        }
    }
}

int main() {
    queue<Dancer> males, females;
    FormLines(males, females);
    printf("Danh sach dien vien nam:\n");
    ShowQueue(males);
    printf("Danh sach dien vien nu:\n");
    ShowQueue(females);
    StartDancing(males, females);
    if (!males.empty() || !females.empty()) {
        HeadOfLine(males, females);
        NewDancers(males, females);
    }
    if (!males.empty() || !females.empty()) {
        HeadOfLine(males, females);
        NewDancers(males, females);
    }
    printf("\n");
    return 0;
}
